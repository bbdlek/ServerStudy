﻿#include "pch.h"
#include <iostream>

int main()
{
	HelloWorld();
}