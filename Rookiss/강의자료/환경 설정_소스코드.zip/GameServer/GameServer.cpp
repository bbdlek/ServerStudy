﻿#include "pch.h"
#include <iostream>
#include "CorePch.h"

int main()
{
	HelloWorld();
}